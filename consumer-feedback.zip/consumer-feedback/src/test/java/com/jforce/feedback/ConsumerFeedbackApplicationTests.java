package com.jforce.feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerFeedbackApplicationTests {

    @Test
    void contextLoads() {
    }

}
